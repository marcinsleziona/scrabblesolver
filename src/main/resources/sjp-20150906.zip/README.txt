
S�ownik SJP.PL - wersja do gier s�ownych

S�ownik udost�pniany na licencjach GPL oraz 
Creative Commons ShareAlike (http://creativecommons.org/licenses/sa/1.0)

Najnowsza wersja s�ownika:
http://sjp.pl/

